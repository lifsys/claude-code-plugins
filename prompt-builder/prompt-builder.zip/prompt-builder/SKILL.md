---
name: prompt-builder
description: |
  Comprehensive prompt specification builder for AI coding agents. This skill guides users through
  structured questioning to produce detailed, production-ready prompt specifications following
  Anthropic's best practices for long-running agent harnesses. Use when users want to create
  application specifications, project prompts, agent instructions, or comprehensive development
  guides. Triggers on requests like "build a prompt", "create an app spec", "help me write
  instructions for an AI agent", or "I need a detailed project specification".
---

# Prompt Builder Skill

Build comprehensive, production-ready prompt specifications through guided questioning. This skill
produces structured specifications optimized for AI coding agents following Anthropic's research
on effective harnesses for long-running agents.

**CRITICAL RULE**: NO section or element may be skipped. ALL elements in the template MUST be
fully and comprehensively completed. Every feature category, every database table, every API
endpoint, every UI component, every design system element, and every success criterion must
be specified.

## Automation Modes

At the START of every prompt building session, present the user with the automation mode choice:

```yaml
- question: "How would you like to build this specification?"
  header: "Build Mode"
  multiSelect: false
  options:
    - label: "Full Automation with Commentary (Recommended)"
      description: "Claude fills ALL answers using provided info + web research, with explanations"
    - label: "Guided with Claude Determines Option"
      description: "Each question includes 'Claude Determines' choice for AI-assisted decisions"
    - label: "Fully Manual"
      description: "You answer every question yourself"
```

### Mode 1: Full Automation with Commentary

When selected:
1. Gather initial project description from user (what they want to build)
2. Use WebSearch to research current best practices for that project type
3. Automatically fill ALL specification sections based on:
   - User's description
   - Reference app analysis (if cloning)
   - Current industry best practices from web research
   - Anthropic's harness recommendations
4. Provide commentary explaining each decision
5. Present complete specification for user review/adjustment
6. User can request changes to any section

**Commentary Format:**
```
## [Section Name]
**Decision**: [What was chosen]
**Reasoning**: [Why this choice based on research/best practices]
**Alternatives Considered**: [Other options and why not chosen]
```

### Mode 2: Guided with "Claude Determines" Option

For EVERY AskUserQuestion, include an additional option:

```yaml
- label: "Claude Determines (Research-Based)"
  description: "Claude will use web search to determine the best current approach"
```

When "Claude Determines" is selected:
1. Use WebSearch tool to research current best practices
2. Analyze search results for consensus recommendations
3. Select the option that best matches:
   - Current industry standards
   - Project requirements
   - Compatibility with other choices
4. Explain the decision with sources

**Research Process:**
```
1. Search: "[technology/approach] best practices 2025"
2. Search: "[technology] vs [alternative] comparison"
3. Search: "[project type] recommended [category]"
4. Synthesize findings into recommendation
5. Cite sources in explanation
```

### Mode 3: Fully Manual

Standard question flow - user answers every question without AI assistance.

---

## Core Principles (from Anthropic Research)

1. **Incremental Progress**: Break work into single-feature sessions
2. **Environment Scaffolding**: Create structured files for progress tracking
3. **JSON over Markdown**: Use JSON for feature lists (models preserve structure better)
4. **Explicit Testing**: Self-verify before marking features complete
5. **Clear State Transitions**: Use git + progress files for documentation
6. **Browser Automation**: Include end-to-end testing capabilities when applicable

---

## MANDATORY Specification Sections

The following sections MUST ALL be completed. No section may be omitted:

### 1. `<project_name>` - REQUIRED
### 2. `<overview>` - REQUIRED
### 3. `<technology_stack>` - REQUIRED
   - `<api_key>` - REQUIRED
   - `<frontend>` - REQUIRED (7 subsections)
   - `<backend>` - REQUIRED (4 subsections)
   - `<communication>` - REQUIRED (3 subsections)
### 4. `<prerequisites>` - REQUIRED
### 5. `<core_features>` - REQUIRED (ALL 14 categories)
   - `<chat_interface>` - 12 features minimum
   - `<artifacts>` - 10 features minimum
   - `<conversation_management>` - 12 features minimum
   - `<projects>` - 8 features minimum
   - `<model_selection>` - 6 features minimum
   - `<custom_instructions>` - 5 features minimum
   - `<settings_preferences>` - 10 features minimum
   - `<advanced_features>` - 10 features minimum
   - `<collaboration>` - 6 features minimum
   - `<search_discovery>` - 6 features minimum
   - `<usage_tracking>` - 5 features minimum
   - `<onboarding>` - 5 features minimum
   - `<accessibility>` - 6 features minimum
   - `<responsive_design>` - 6 features minimum
### 6. `<database_schema>` - REQUIRED (ALL tables)
   - users, projects, conversations, messages, artifacts
   - shared_conversations, prompt_library, conversation_folders
   - conversation_folder_items, usage_tracking, api_keys
### 7. `<api_endpoints_summary>` - REQUIRED (ALL endpoint groups)
   - authentication, conversations, messages, artifacts
   - projects, sharing, prompts, search, folders
   - usage, settings, external_api
### 8. `<ui_layout>` - REQUIRED (ALL sections)
   - `<main_structure>` - 5 items minimum
   - `<sidebar_left>` - 7 items minimum
   - `<main_chat_area>` - 9 items minimum
   - `<artifacts_panel>` - 8 items minimum
   - `<modals_overlays>` - 7 items minimum
### 9. `<design_system>` - REQUIRED (ALL sections)
   - `<color_palette>` - 6 color definitions with hex codes
   - `<typography>` - 5 typography rules
   - `<components>` - message_bubble, buttons, inputs, cards
   - `<animations>` - 6 animation definitions
### 10. `<key_interactions>` - REQUIRED (ALL flows)
   - `<message_flow>` - 9 steps
   - `<artifact_flow>` - 8 steps
   - `<conversation_management>` - 8 steps
### 11. `<implementation_steps>` - REQUIRED (9 steps)
   - Each step with title and 6+ tasks
### 12. `<success_criteria>` - REQUIRED (ALL 4 categories)
   - `<functionality>` - 6 criteria
   - `<user_experience>` - 6 criteria
   - `<technical_quality>` - 6 criteria
   - `<design_polish>` - 6 criteria

---

## Prompt Building Workflow

### Phase 0: Automation Mode Selection

**FIRST QUESTION - ALWAYS ASK:**
```yaml
- question: "How would you like to build this specification?"
  header: "Build Mode"
  multiSelect: false
  options:
    - label: "Full Automation with Commentary (Recommended)"
      description: "Claude fills ALL answers using provided info + web research, with explanations"
    - label: "Guided with Claude Determines Option"
      description: "Each question includes 'Claude Determines' choice for AI-assisted decisions"
    - label: "Fully Manual"
      description: "You answer every question yourself"
```

### Phase 1: Project Foundation

**Question Set 1: Project Identity**
```yaml
- question: "What type of project are you building?"
  header: "Project Type"
  multiSelect: false
  options:
    - label: "Web Application"
      description: "Full-stack web app with frontend and backend"
    - label: "CLI Tool"
      description: "Command-line interface application"
    - label: "API Service"
      description: "Backend API or microservice"
    - label: "Library/SDK"
      description: "Reusable code package"
    - label: "Claude Determines (Research-Based)"  # Include if Mode 2
      description: "Claude will analyze your description and determine best project type"
```

**Question Set 2: Project Scope**
```yaml
- question: "What is the scale and complexity of this project?"
  header: "Scope"
  multiSelect: false
  options:
    - label: "MVP/Prototype"
      description: "Minimal viable product for validation"
    - label: "Production App"
      description: "Full-featured production-ready application"
    - label: "Enterprise System"
      description: "Large-scale system with complex requirements"
    - label: "Claude Determines (Research-Based)"  # Include if Mode 2
      description: "Claude will recommend scope based on project requirements"
```

**Question Set 3: Reference Application**
```yaml
- question: "Is there an existing application this should clone or be inspired by?"
  header: "Reference"
  multiSelect: false
  options:
    - label: "Yes, clone existing app"
      description: "Replicate an existing application's features"
    - label: "Yes, inspired by"
      description: "Take inspiration but with modifications"
    - label: "No, original design"
      description: "Building something new from scratch"
```

If cloning/inspired: "Please provide the app name and URL for reference analysis"

### Phase 2: Technology Stack (ALL subsections required)

For EACH technology choice, include "Claude Determines" option if Mode 2:

**Frontend Framework:**
```yaml
- question: "Which frontend framework should be used?"
  header: "Framework"
  options:
    - label: "React with Vite (Recommended)"
      description: "Popular, fast builds, large ecosystem"
    - label: "Vue 3"
      description: "Progressive framework, gentle learning curve"
    - label: "Svelte/SvelteKit"
      description: "Compile-time framework, smaller bundles"
    - label: "Next.js"
      description: "React with SSR/SSG, file-based routing"
    - label: "Claude Determines (Research-Based)"
      description: "Claude researches current best framework for your use case"
```

**Continue for ALL technology choices:**
- Styling approach
- State management
- Routing
- Markdown rendering
- Code highlighting
- Port configuration
- Backend runtime
- Database
- API integration
- Streaming method
- API style
- External API integration

### Phase 3: Core Features (ALL 14 Categories Required)

For EACH of the 14 feature categories, gather comprehensive feature lists.

**Category Selection:**
```yaml
- question: "Which feature categories apply to your project?"
  header: "Categories"
  multiSelect: true
  options:
    - label: "Chat Interface"
      description: "Message input, streaming, markdown, code blocks"
    - label: "Artifacts/Output Panel"
      description: "Code preview, HTML render, versioning"
    - label: "Conversation Management"
      description: "Create, list, rename, delete, search, organize"
    - label: "Projects/Workspaces"
      description: "Group conversations, knowledge base, settings"
    # ... continue for all 14 categories
    - label: "Claude Determines (Research-Based)"
      description: "Claude analyzes your project and selects all relevant categories"
```

**IMPORTANT**: Even if user doesn't select all categories, the final specification MUST include
appropriate features for ALL 14 categories. If user doesn't select a category, Claude must
determine appropriate default features for that category.

### Phase 4: Data Architecture (ALL tables required)

**Entity Selection:**
```yaml
- question: "What are the main data entities in your system?"
  header: "Entities"
  multiSelect: true
  options:
    - label: "Users/Accounts"
    - label: "Projects/Workspaces"
    - label: "Conversations/Chats"
    - label: "Messages"
    - label: "Artifacts/Outputs"
    - label: "Folders"
    - label: "Shared Items"
    - label: "Prompt Library"
    - label: "Usage Records"
    - label: "API Keys"
    - label: "Claude Determines (Research-Based)"
      description: "Claude determines all required entities based on features"
```

**IMPORTANT**: Final specification MUST include ALL standard tables regardless of selection.

### Phase 5: UI/UX Specifications (ALL sections required)

**Layout Structure:**
```yaml
- question: "What is the primary layout structure?"
  header: "Layout"
  options:
    - label: "Three Column"
      description: "Sidebar + main content + artifacts panel"
    - label: "Two Column"
      description: "Sidebar + main content"
    - label: "Single Column"
      description: "Focused, linear flow"
    - label: "Dashboard Grid"
      description: "Multiple widgets/cards layout"
    - label: "Claude Determines (Research-Based)"
      description: "Claude researches best layout for your app type"
```

**Continue for ALL UI/UX elements:**
- Sidebar features (7+ items)
- Main area features (9+ items)
- Artifacts panel features (8+ items)
- Modals/overlays (7+ items)
- Color palette (6 colors with hex)
- Typography (5 rules)
- Component styles (4 component types)
- Animations (6 definitions)

### Phase 6: Implementation Roadmap (9 Steps Required)

**Step Ordering:**
```yaml
- question: "What should be built first?"
  header: "Priority"
  options:
    - label: "Backend first"
      description: "API and data layer, then UI"
    - label: "Frontend first"
      description: "UI with mocked data, then backend"
    - label: "Full-stack features"
      description: "Complete vertical slices"
    - label: "Claude Determines (Research-Based)"
      description: "Claude researches optimal build order for your project"
```

**IMPORTANT**: Final specification MUST include all 9 implementation steps with 6+ tasks each.

### Phase 7: Success Criteria (ALL 4 categories required)

For EACH of the 4 success criteria categories, gather 6 specific criteria:

```yaml
- question: "What functionality must work?"
  header: "Functionality"
  multiSelect: true
  options:
    - label: "Streaming responses work smoothly"
    - label: "Artifact detection accurate"
    - label: "Conversation management reliable"
    - label: "Project organization useful"
    - label: "Image upload working"
    - label: "All CRUD functional"
    - label: "Claude Determines (Research-Based)"
      description: "Claude determines comprehensive functionality criteria"
```

**Repeat for:**
- User Experience (6 criteria)
- Technical Quality (6 criteria)
- Design Polish (6 criteria)

---

## Output Generation

After ALL phases complete, generate:

### 1. Complete XML Specification
Use `references/spec_template.md` as the template. Fill EVERY section completely.

### 2. Feature List JSON
Use `assets/feature_list_template.json`. Include ALL features with tests.

### 3. Progress Tracking File
Use `assets/progress_template.txt`. Initialize with all features as "failing".

### 4. Initialization Script
Use `assets/init_script_template.sh`. Customize for project's technology stack.

---

## Validation Checklist

Before presenting final specification, verify:

- [ ] `<project_name>` - Filled with descriptive name
- [ ] `<overview>` - 2-4 sentences, mentions key features
- [ ] `<technology_stack>` - ALL 14 subsections filled
- [ ] `<prerequisites>` - Environment setup documented
- [ ] `<core_features>` - ALL 14 categories with minimum features
- [ ] `<database_schema>` - ALL 11 tables defined
- [ ] `<api_endpoints_summary>` - ALL 12 endpoint groups
- [ ] `<ui_layout>` - ALL 5 sections with minimum items
- [ ] `<design_system>` - ALL 4 sections complete
- [ ] `<key_interactions>` - ALL 3 flows with steps
- [ ] `<implementation_steps>` - 9 steps, 6+ tasks each
- [ ] `<success_criteria>` - ALL 4 categories, 6 criteria each

**If ANY section is incomplete, DO NOT present to user. Complete it first.**

---

## Web Research Guidelines

When using WebSearch for "Claude Determines" decisions:

**Search Patterns:**
```
1. "[technology] best practices 2025"
2. "[technology A] vs [technology B] comparison 2025"
3. "best [category] for [project type] 2025"
4. "[reference app] technology stack"
5. "[project type] architecture patterns"
```

**Evaluation Criteria:**
1. Recency - Prefer 2024-2025 sources
2. Authority - Official docs, major tech blogs, reputable developers
3. Consensus - Multiple sources agreeing
4. Compatibility - Works with other chosen technologies
5. Community - Active maintenance, good ecosystem

**Citation Format:**
```
**Decision**: [Choice]
**Sources**:
- [Source 1 title](URL) - Key finding
- [Source 2 title](URL) - Supporting evidence
**Reasoning**: [Synthesis of findings]
```

---

## Resources

### references/
- `spec_template.md` - Complete XML template with ALL sections
- `question_bank.md` - Full question library for ALL phases
- `feature_patterns.md` - Implementation patterns for ALL 14 categories

### assets/
- `feature_list_template.json` - JSON template for feature tracking
- `progress_template.txt` - Progress file template
- `init_script_template.sh` - Initialization script template
